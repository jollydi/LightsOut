package com.example.lightsout

object Constants {

    const val TAG = "LO"
}